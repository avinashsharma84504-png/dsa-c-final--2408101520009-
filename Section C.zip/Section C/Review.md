## C1 Defect Report
|NO | Line | Defect       | Conequences|
|---|------|--------------|-----------|
|1  | 1    |No Header file|Code Error |
|2  |14    | return head  | code Error|
   

    Corrected	function:	SectionC/C1_reverse.c
Complexity:	Time	O(n),	Space	O(1)