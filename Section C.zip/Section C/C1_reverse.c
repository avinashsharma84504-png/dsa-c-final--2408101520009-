#include <stddef.h>

typedef struct Node { int data; struct Node *next;}
 Node;

Node *reverse_list(Node *head) {
    Node *prev = NULL, *curr = head, *next = NULL;
    while (curr != NULL) {
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    return prev;
}
