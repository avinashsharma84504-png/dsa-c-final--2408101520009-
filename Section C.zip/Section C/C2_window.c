int	longest_block(int *a, int n, long long L)	{
 int best =	0;
	for	(int i = 0;	i < n; i++)	{
	long long sum =	0;
	for	(int j = i;	j < n; j++)	
    {
	sum	+= a[j];
	if	(sum <= L && (j	-	i	+	1) > best)
	best = j - i + 1;
	}
	}
	return	best;
	}