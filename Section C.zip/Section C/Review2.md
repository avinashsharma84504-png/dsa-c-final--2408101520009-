## C1 Defect Report
|NO | Line | Defect       | Conequences|
|---|------|--------------|-----------|
|1  | 1    | |
|2  |14    | |                        |

    Corrected	function:	SectionC/C1_reverse.c
Complexity:	Time	O(n),	Space	O(1)