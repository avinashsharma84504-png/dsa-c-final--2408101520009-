#include <stdio.h>
#include <string.h>

#define MAX 100
#define SIZE 50

// Stack structure
typedef struct {
    char pages[MAX][SIZE];
    int top;
} Stack;

// Initialize stack
void init(Stack *s) {
    s->top = -1;
}

// Check if stack is empty
int isEmpty(Stack *s) {
    return s->top == -1;
}

// Push page onto stack
void push(Stack *s, char page[]) {
    if (s->top == MAX - 1) {
        printf("Stack Overflow!\n");
        return;
    }
    s->top++;
    strcpy(s->pages[s->top], page);
}

// Pop page from stack
void pop(Stack *s, char page[]) {
    if (isEmpty(s)) {
        printf("Stack Underflow!\n");
        return;
    }
    strcpy(page, s->pages[s->top]);
    s->top--;
}

// Clear stack
void clear(Stack *s) {
    s->top = -1;
}

int main() {
    Stack backStack, forwardStack;
    char currentPage[SIZE] = "Home";
    char page[SIZE];
    int choice;

    init(&backStack);
    init(&forwardStack);

    while (1) {
        printf("\n----------------------------\n");
        printf("Current Page : %s\n", currentPage);
        printf("----------------------------\n");
        printf("1. Visit New Page\n");
        printf("2. Back\n");
        printf("3. Forward\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {

        case 1:
            printf("Enter page name: ");
            scanf("%s", page);

            // Save current page in back stack
            push(&backStack, currentPage);

            // New page becomes current
            strcpy(currentPage, page);

            // Clear forward history
            clear(&forwardStack);

            printf("Visited %s\n", currentPage);
            break;

        case 2:
            if (isEmpty(&backStack)) {
                printf("No previous page available.\n");
            } else {
                push(&forwardStack, currentPage);
                pop(&backStack, currentPage);
                printf("Moved Back to %s\n", currentPage);
            }
            break;

        case 3:
            if (isEmpty(&forwardStack)) {
                printf("No forward page available.\n");
            } else {
                push(&backStack, currentPage);
                pop(&forwardStack, currentPage);
                printf("Moved Forward to %s\n", currentPage);
            }
            break;

        case 4:
            printf("Exiting Browser...\n");
            return 0;

        default:
            printf("Invalid choice!\n");
        }
    }

    return 0;
}