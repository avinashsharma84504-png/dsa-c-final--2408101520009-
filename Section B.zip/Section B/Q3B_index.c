#include <stdio.h>
#include <stdlib.h>

// Structure of BST Node
struct Node {
    int id;
    struct Node *left;
    struct Node *right;
};

// Create a new node
struct Node* createNode(int id) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->id = id;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

// Insert a node into BST
struct Node* insert(struct Node* root, int id) {
    if (root == NULL)
        return createNode(id);

    if (id < root->id)
        root->left = insert(root->left, id);
    else if (id > root->id)
        root->right = insert(root->right, id);

    return root;
}

// Search an employee ID
struct Node* search(struct Node* root, int key) {
    if (root == NULL || root->id == key)
        return root;

    if (key < root->id)
        return search(root->left, key);

    return search(root->right, key);
}

// Inorder Traversal
void inorder(struct Node* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->id);
        inorder(root->right);
    }
}

// Preorder Traversal
void preorder(struct Node* root) {
    if (root != NULL) {
        printf("%d ", root->id);
        preorder(root->left);
        preorder(root->right);
    }
}

// Postorder Traversal
void postorder(struct Node* root) {
    if (root != NULL) {
        postorder(root->left);
        postorder(root->right);
        printf("%d ", root->id);
    }
}

int main() {
    struct Node* root = NULL;
    int n, id, choice, key;

    printf("Enter number of employee IDs: ");
    scanf("%d", &n);

    printf("Enter employee IDs:\n");
    for (int i = 0; i < n; i++) {
        scanf("%d", &id);
        root = insert(root, id);
    }

    while (1) {
        printf("\n------ BST MENU ------\n");
        printf("1. Insert Employee ID\n");
        printf("2. Search Employee ID\n");
        printf("3. Display Inorder (Sorted IDs)\n");
        printf("4. Display Preorder\n");
        printf("5. Display Postorder\n");
        printf("6. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter Employee ID to insert: ");
                scanf("%d", &id);
                root = insert(root, id);
                printf("Employee ID inserted.\n");
                break;

            case 2:
                printf("Enter Employee ID to search: ");
                scanf("%d", &key);

                if (search(root, key))
                    printf("Employee ID %d found.\n", key);
                else
                    printf("Employee ID %d not found.\n", key);
                break;

            case 3:
                printf("Employee IDs in sorted order:\n");
                inorder(root);
                printf("\n");
                break;

            case 4:
                printf("Preorder Traversal:\n");
                preorder(root);
                printf("\n");
                break;

            case 5:
                printf("Postorder Traversal:\n");
                postorder(root);
                printf("\n");
                break;

            case 6:
                printf("Exiting...\n");
                return 0;

            default:
                printf("Invalid choice!\n");
        }
    }

    return 0;
}